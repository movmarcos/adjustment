#Author: Marcos Magri
#Date: 15/12/20
#Purpose: To create a JWT from cert store certificate and make request with it
#       : to Azure API to get OAuth token for later use in Python script
#Version: 1.0
#Note: Adapted from https://adamtheautomator.com/microsoft-graph-api-powershell/

class PSCode():

    def get_oauth_token_cmd(scope, environment, cert_name, sp_id, tenant_id):
        return '''
$scope = "<replace_scope>"
$environment = "<replace_environment>"
$certName = "<replace_certName>"
$applicationId = "<replace_applicationId>"
$tenantId = "<replace_tenantId>"

$env:HTTPS_PROXY="dummy.invalid"
$env:NO_PROXY="*"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12


###################################################################


write-host "TENANT ID:",$tenantId
write-host "CERTIFICATE NAME:", $certName
write-host "APP ID:", $applicationId
write-host "TOKEN SCOPE:", $scope

#POWERSHELL VERSION

# Get Certificate Thumbprint
try {
    $Thumbprint = (Get-ChildItem -path Cert:\* -Recurse -ErrorAction SilentlyContinue | Where-Object {$_.GetType().Name -eq "X509Certificate2" } | Where-Object { $_.Subject -like "CN=$certName*" } | Sort-Object -Property NotAfter -Descending).Thumbprint | Select-Object -First 1
    if ([string]::IsNullOrWhiteSpace($Thumbprint)) {
        Write-Host "Unable to find CertName: $certName"
        exit 1
    } 
}catch {
    $Log.ErrorFormat("Unable to read CertName={0}; {1}; {2}", $certName, $_.ScriptStackTrace, $_)
    Write-Host "Unable to read CertName"
    exit 1
}

$CertPath = "Cert:\*" + $Thumbprint
$Certificate = Get-ChildItem -path $CertPath -Recurse

if ($null -eq $Certificate){
    write-host "NO CERTIFICATE FOUND WITH THUMBPRINT",$Thumbprint
    exit
}

# Create base64 hash of certificate
$CertificateBase64Hash = [System.Convert]::ToBase64String($Certificate.GetCertHash())

# Create JWT timestamp for expiration
$StartDate = (Get-Date "1970-01-01T00:00:00Z" ).ToUniversalTime()
$JWTExpirationTimeSpan = (New-TimeSpan -Start $StartDate -End (Get-Date).ToUniversalTime().AddMinutes(2)).TotalSeconds
$JWTExpiration = [math]::Round($JWTExpirationTimeSpan,0)

# Create JWT validity start timestamp
$NotBeforeExpirationTimeSpan = (New-TimeSpan -Start $StartDate -End ((Get-Date).ToUniversalTime())).TotalSeconds
$NotBefore = [math]::Round($NotBeforeExpirationTimeSpan,0)

# Create JWT header
$JWTHeader = @{
    alg = "RS256"
    typ = "JWT"
    # Use the CertificateBase64Hash and replace/strip to match web encoding of base64
    x5t = $CertificateBase64Hash -replace '\+','-' -replace '/','_' -replace '='
}

# Create JWT payload
$JWTPayLoad = @{
    # What endpoint is allowed to use this JWT
    aud = "https://login.microsoftonline.com/$tenantId/oauth2/token"

    # Expiration timestamp
    exp = $JWTExpiration

    # Issuer = your application
    iss = $applicationId

    # JWT ID: random guid
    jti = [guid]::NewGuid()

    # Not to be used before
    nbf = $NotBefore

    # JWT Subject
    sub = $applicationId
}

# Convert header and payload to base64
$JWTHeaderToByte = [System.Text.Encoding]::UTF8.GetBytes(($JWTHeader | ConvertTo-Json))
$EncodedHeader = [System.Convert]::ToBase64String($JWTHeaderToByte)

$JWTPayLoadToByte =  [System.Text.Encoding]::UTF8.GetBytes(($JWTPayload | ConvertTo-Json))
$EncodedPayload = [System.Convert]::ToBase64String($JWTPayLoadToByte)

# Join header and Payload with "." to create a valid (unsigned) JWT
$JWT = $EncodedHeader + "." + $EncodedPayload

# Get the private key object of your certificate
$PrivateKey = $Certificate.PrivateKey

# Define RSA signature and hashing algorithm
$RSAPadding = [Security.Cryptography.RSASignaturePadding]::Pkcs1
$HashAlgorithm = [Security.Cryptography.HashAlgorithmName]::SHA256


# Create a signature of the JWT
try {
$Signature = [Convert]::ToBase64String(
    $PrivateKey.SignData([System.Text.Encoding]::UTF8.GetBytes($JWT),$HashAlgorithm,$RSAPadding)
) -replace '\+','-' -replace '/','_' -replace '='
}
catch {
write-host "ERROR IN SIGNING CERT, MAKE SURE YOU ARE RUNNING AS ADMINISTRATOR"
exit}

# Join the signature to the JWT with "."
$JWT = $JWT + "." + $Signature

# Create a hash with body parameters
$Body = @{
    client_id = $applicationId
    client_assertion = $JWT
    client_assertion_type = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"
    scope = $scope
    grant_type = "client_credentials"
}

$Url = "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token"

# Use the self-generated JWT as Authorization
$Header = @{
    Authorization = "Bearer $JWT"
}

# Splat the parameters for Invoke-Restmethod for cleaner code
$PostSplat = @{
    ContentType = 'application/x-www-form-urlencoded'
    Method = 'POST'
    Body = $Body
    Uri = $Url
    Headers = $Header
}

$Request = Invoke-RestMethod @PostSplat
$myToken = $Request.access_token
$myTokenType = $Request.token_type
$expiresIn = $Request.expires_in

write-host "OAUTH_TOKEN$($myTokenType) $($myToken) $($expiresIn)OAUTH_TOKEN"

'''.replace("<replace_scope>", scope) \
    .replace("<replace_environment>",environment) \
    .replace("<replace_certName>", cert_name) \
    .replace("<replace_applicationId>", sp_id) \
    .replace("<replace_tenantId>", tenant_id)