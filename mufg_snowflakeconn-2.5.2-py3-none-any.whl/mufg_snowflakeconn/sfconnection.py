import os, errno
import re
import json, yaml
from azure.keyvault.secrets import SecretClient
from mufg_snowflakeconn import cred_wrapper as cw

# Import for Snowflake Connection
import snowflake.connector
from snowflake.snowpark import Session
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization

class MufgSnowflakeConn():

    def __init__(self, environment, user_name, **kwargs):
        """
            Args:
                environment (str):   Used to automatic identify Key Vault and Certificate (dvlp, test, rlse or prod)
                user_name (str):     Snowflake user name

            **Keyword Args:
                account (str):      Snowflake account
                                    Default: tj90313.west-europe.privatelink
                scope (str):        Used to automatic identify Key Vault and Certificate combined with environment
                                    Default: raptor
                kv_name (str):      Key Vault name where the private key and passphrase are stored for the Snowflake User.
                sp_id (str):        Service Pricipal ID created in Azure Portal
                cert_name (str):    Certificate name (pfx) locally imported - Created to authenticate the Service Principal
                                    Usually it is valid for one year
                kv_secret (str):    Prefix for the secrets in Key Vault
                                    Default: user_name - non letters and numbers characters are removed
                                    Example: kv_secret+"-SnowflakePrivateKey"
                                             kv_secret+"-SnowflakePrivateKeyPassPhrase"
                is_pkb_local (bool): Indicate whether the private key is stored locally and not in Key Vault
                                     Default: False
                                     If True: Two environment variable must be set or the the file path must be provided
                                     Environment Variable
                                        SF_PASSPHRASE_PATH: passphrase file path
                                        SF_PRIVATE_KEY_PATH: private key file path
                sf_passphrase_path (str):  passphrase file path
                sf_private_key_path (str): private key file path
                tenant_id (str)
                export_key_path (str):  Export the certificate to a file to the path provided.
            
        """
        self.environment = environment.lower()
        self.user_name = user_name.lower()

        # Scope
        self.tenant_id = str(kwargs.get('tenant_id', '3419f996-06ae-4fa7-a22f-337b4f095d9f'))
        self.scope = str(kwargs.get('scope', 'raptor'))

        # Snowflake Account
        self.account = str(kwargs.get('account', "tj90313.west-europe.privatelink"))

        # Key Vault Name
        self.kv_name = str(kwargs.get('kv_name', f"euntborisk{self.scope}kv{self.environment}"))

        # Local Key Pair
        self.is_pkb_local = bool(kwargs.get('is_pkb_local', False))
        self.sf_passphrase_path = kwargs.get('sf_passphrase_path', '')
        self.sf_private_key_path = kwargs.get('sf_private_key_path', '')


        # Certificate name
        if "BLD" in os.environ['COMPUTERNAME']:
            cert_name = f"{self.scope}-snowflake-build-{self.environment}"
        else:
            cert_name = f"{self.scope}-snowflake-{self.environment}"
        self.cert_name = kwargs.get('cert_name', cert_name)

        # Service Principal ID
        sp_id = ""
        if ("raptor-snowflake-build-dvlp" == self.cert_name)      : sp_id = "b22f456a-f2c2-4e12-90c0-5a0b955fe78a"
        elif ("raptor-snowflake-dvlp" == self.cert_name)          : sp_id = "a1ca7398-dfb9-4bed-9b7f-014e3e829911"
        elif ("raptor-snowflake-build-test" == self.cert_name)    : sp_id = "29c731ce-4ff5-44de-b07f-a150b960a534"
        elif ("raptor-snowflake-test" == self.cert_name)          : sp_id = "f8382a4f-8aaf-45f7-85c4-99675ce33bdf"
        elif ("raptor-snowflake-build-rlse" == self.cert_name)    : sp_id = "0b1d5cf9-34d0-491c-9bf1-d14a0e6b94a3"
        elif ("raptor-snowflake-rlse" == self.cert_name)          : sp_id = "1bda6b73-4d5d-4104-a326-4a24c7564449"
        elif ("raptor-snowflake-build-prod" == self.cert_name)    : sp_id = "f3ab6ee7-2683-4e9e-8ae6-7ac4ebe3a5d1"
        elif ("raptor-snowflake-prod" == self.cert_name)          : sp_id = "f6a3122c-d772-4e49-980b-d37adf252ea8"
        self.sp_id = kwargs.get('sp_id', sp_id)

        # Prefix for the secrets in Key Vault
        self.user = re.sub('[^A-Za-z0-9]+', '', self.user_name) # Remove characters that are not a letters or numbers
        self.kv_secret = kwargs.get('kv_secret', self.user)

        self.export_key_path = kwargs.get('export_key_path', '')

    def export_key(self, private_key, private_key_passphrase):
        """
            Export the private key and passphrase to a file to the path provided.
            private_key (str):  Snowflake private key
            private_key_passphrase (str):  Snowflake private key passphrase
        """
        
        if self.export_key_path:            
            user = self.user
            folder_path = self.export_key_path

            try:
                os.makedirs(folder_path)
            except OSError as e:
                if e.errno != errno.EEXIST:
                    raise Exception("Failed to create folder {}".format(folder_path)) from e
            
            # Private Key export
            pv_path = f"{folder_path}\\{user}-SnowflakePrivateKey.p8"
            pv_file = open(pv_path, "w")
            pv_file.write(private_key)
            print(pv_path)
            pv_file.close()

            # Private Key Passphrase export
            pp_path = f"{folder_path}\\{user}-SnowflakePrivateKeyPassphrase.txt"
            pp_file = open(pp_path, "w")
            pp_file.write(private_key_passphrase)
            print(pp_path)
            pp_file.close()
            
    def get_private_key(self):
        return self.get_local_private_key() if self.is_pkb_local else self.get_kv_private_key()            
    
    def get_local_private_key(self):
        key_path = self.sf_private_key_path if self.sf_private_key_path else os.getenv('SF_PRIVATE_KEY_PATH')
        passphrase_path = self.sf_passphrase_path if self.sf_passphrase_path else os.getenv('SF_PASSPHRASE_PATH')
        
        f = open(passphrase_path, "r")
        passphrase = f.read().strip()

        with open(key_path, "rb") as key:
            p_key= serialization.load_pem_private_key(
                key.read(),
                password=passphrase.encode(),
                backend=default_backend()
            )

        pkb = p_key.private_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption())

        return pkb
    
    def get_aad_creds(self, az_scope):
        client = cw.AuthTokenClient()
        vault_creds = client.generate_aad_creds(az_scope,self.environment,self.cert_name,self.sp_id, self.tenant_id)
        return vault_creds
    
    def get_kv_private_key(self):
        # Get Key Vaul Secret Client
        vault_url = f"https://{self.kv_name}.vault.azure.net/"
        vault_scope = "https://vault.azure.net/.default"
        vault_creds = self.get_aad_creds(vault_scope)
        secret_client = SecretClient(vault_url=vault_url, credential=vault_creds)
        print("Key Vault connected: {}".format(vault_url))

        # Get secrets
        SnowflakeUserName = self.user_name
        SnowflakePrivateKey = secret_client.get_secret(self.kv_secret+"-SnowflakePrivateKey").value
        SnowflakePrivateKeyPassPhrase = secret_client.get_secret(self.kv_secret+"-SnowflakePrivateKeyPassPhrase").value

        # Way to use private key generated by Key Rotation or manual
        headerFooter = ["-----BEGIN ENCRYPTED PRIVATE KEY-----","-----END ENCRYPTED PRIVATE KEY-----",""]
        privs = SnowflakePrivateKey.split("\n")
        privs = [line for line in privs if line not in headerFooter]
        priv = " ".join(privs)
        priv = "\n".join(priv.split(" "))
        priv = headerFooter[0] + "\n" + priv + "\n" + headerFooter[1]

        if self.export_key_path:
            self.export_key(priv,SnowflakePrivateKeyPassPhrase)

        p_key= serialization.load_pem_private_key(
            priv.encode(),
            password=SnowflakePrivateKeyPassPhrase.encode(),
            backend=default_backend()
        )
        
        pkb = p_key.private_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption())
        return pkb

    def snowflake_conn(self,sf_type,is_external): 
        connection_parameters = {
            "account": self.account,
            "user": self.user_name
        }
        conn_info = {}
        conn_info['Snowflake Connection'] = connection_parameters
        if not self.is_pkb_local:
            kv_info = {}
            kv_info["kv_name"] = self.kv_name
            kv_info["cert_name"] = self.cert_name
            kv_info["sp_id"] = self.sp_id
            conn_info['Secrets in Key Vault'] = kv_info
        print(yaml.dump(conn_info))

        if is_external:
            connection_parameters["authenticator"] = "externalbrowser"
        else:
            connection_parameters["private_key"] = self.get_private_key()

        if sf_type == "snowflake_snowpark":
            session_builder = Session.builder.configs(connection_parameters).create()
            print("Snowpark session created")
            return session_builder
        else:
            print("Snowflake connection created")
            return snowflake.connector.connect(**connection_parameters)

    def get_snowflake_conn(self):
        return self.snowflake_conn("snowflake_connector",False)

    def get_snowflake_conn_ext(self):
        return self.snowflake_conn("snowflake_connector",True)

    def get_snowflake_cursor(self):
        conn = self.snowflake_conn("snowflake_connector",False)
        return conn.cursor()

    def get_snowflake_cursor_ext(self):
        conn = self.snowflake_conn("snowflake_connector",True)
        return conn.cursor()

    def get_snowflake_session(self):
        return self.snowflake_conn("snowflake_snowpark",False)

    def get_snowflake_session_ext(self):
        return self.snowflake_conn("snowflake_snowpark",True)
        