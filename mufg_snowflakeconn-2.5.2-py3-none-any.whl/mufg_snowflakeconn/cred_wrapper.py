
import os,re,sys
from subprocess import check_output
from datetime import timedelta,datetime
from msrest.authentication import BasicTokenAuthentication
from azure.core.pipeline.policies import BearerTokenCredentialPolicy
from azure.core.pipeline import PipelineRequest, PipelineContext
from azure.core.pipeline.transport import HttpRequest
from azure.core.credentials import AccessToken
from mufg_snowflakeconn.ps_code import PSCode

scope = "https://management.azure.com/.default"

class CredentialWrapper(BasicTokenAuthentication):
    def __init__(
        self,
        *args,
        credential=None,
        resource_id="https://management.azure.com/.default",
        **kwargs
    ):
        """Wrap any azure-identity credential to work with SDK that needs 
        azure.common.credentials/msrestazure.
        Default resource is ARM (syntax of endpoint v2)
        Code partly provided by Microsoft at 
        https://gist.github.com/lmazuel/cc683d82ea1d7b40208de7c9fc8de59d
        :param credential: Any azure-identity credential (StaticTokenCredential
        by default)
        :param str resource_id: The scope to use to get the token (default ARM)
        """
        super().__init__(None)
        if credential is None:
            credential = StaticTokenCredential(*args)
        self._policy = BearerTokenCredentialPolicy(credential, resource_id, **kwargs)
        self.scope = resource_id

    def _make_request(self):
        return PipelineRequest(
            HttpRequest("CredentialWrapper", "https://fakeurl"), PipelineContext(None)
        )

    def set_token(self):
        """Ask the azure-core BearerTokenCredentialPolicy policy to get a token.
        Using the policy gives us for free the caching system of azure-core.
        We could make this code simpler by using private method, but by definition
        I can't assure they will be there forever, so mocking a fake call to the policy
        to extract the token, using 100% public API."""
        request = self._make_request()
        self._policy.on_request(request)
        # Read Authorization, and get the second part after Bearer
        token = request.http_request.headers["Authorization"].split(" ", 1)[1]
        self.token = {"access_token": token}

    def signed_session(self, session=None):
        self.set_token()
        return super(CredentialWrapper, self).signed_session(session)
    
class StaticTokenCredential(CredentialWrapper):
    """Authenticates with a previously acquired access token
    Note that an access token is valid only for certain resources and
    eventually expires. This credential is therefore
    quite limited. An application using it must ensure the token is valid and
    contains all claims required by any service client given an instance of
    this credential.
    """

    def __init__(self, access_token, scope,environment,cert_name,sp_id,tenant_id):
        self.expires_on = datetime.now() + timedelta(seconds = int(access_token['expires_in']))
        # type: (Union[str, AccessToken]) -> None
        if isinstance(access_token, AccessToken):
            self._token = access_token
        else:
            # setting expires_on in the past causes Azure SDK clients to call get_token every time they need a token
            self._token = AccessToken(token=access_token["accessToken"], expires_on=0)
        super().__init__(credential=self,resource_id=scope)

    def is_expired(self):
        return self.expires_on < datetime.now()

    def get_token(self, *scopes, **kwargs):
        # type: (*str, **Any) -> AccessToken

        return self._token


class AuthTokenClient:
    def __init__(self):
        """
        Class to hold authentication details for passed in token for a
        specific client.
        Every method should be decorated with @update_token. this refreshes
        the token saved with the one found at token_fpath
        """
        self.tok = None

    def scope_wrap(func):
        """
        Decorator to allow us to pass scope as a variable to the update token
        factory, but passing it from the function argument of the method,
        which allows it to be dynamic. Also saves us writing out every
        method in the class
        """
        def wrap_func(self,scope,environment,cert_name,sp_id,tenant_id, *args, **kwargs):
            @update_token_factory(scope,environment,cert_name,sp_id,tenant_id)
            def _func(*args, **kwargs):
                return func(*args, **kwargs)

            return _func(self,scope,environment,cert_name,sp_id,tenant_id,*args, **kwargs)

        return wrap_func

    @scope_wrap
    def generate_shared_creds(self):
        """
        returns SharedTokenCacheCredential using a Powershell's auth
        session.
        """
        return SharedTokenCacheCredential()

    @scope_wrap
    def generate_aad_creds(self,scope,environment,cert_name,sp_id,tenant_id):
        """
        Returns AADcredentials for a manually generated token e.g. if this
        script is run by a powershell command
        """
        return StaticTokenCredential(self.tok,scope,environment,cert_name,sp_id,tenant_id)

def update_token_factory(scope,environment,cert_name,sp_id,tenant_id):
    def update_token(func):
        def wrapper(self, *args, **kwargs):
            """
            Assumes token output looks like
            'OAUTH_TOKEN<tok_type> <token> <expires_in>OAUTH_TOKEN'
            Updates the stored token. Called as if an instance method ie first
            arg is instance
            """
            cmd_ps = PSCode.get_oauth_token_cmd(scope,environment,cert_name,sp_id,tenant_id)

            tok = check_output(
                [
                    "powershell.exe",
                    cmd_ps
                ],
                universal_newlines=True,
            )
            try:
                tok = re.search("(?<=OAUTH_TOKEN).+(?=OAUTH_TOKEN)", tok).group(0)
                tok = tok.split()
                self.tok = {"tokenType": tok[0], "accessToken": tok[1], 'expires_in':tok[2]}
                print(f"Obtained new token for scope:{scope}")
            except (AttributeError, IndexError):
                sys.exit(
                    "No token found in PS output. Format: OAUTH TOKEN<tok_type> <tok>OAUTH TOKEN"+
                    f"PWSH Output:{tok}"
                )
            return func(self, *args, **kwargs)

        return wrapper

    return update_token
